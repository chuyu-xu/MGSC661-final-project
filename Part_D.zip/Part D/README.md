# Part D: Prototype and Diagnostics

All work uses Part A's shared split (`random_state=42`), `model_spec.json` and coefficients, unchanged.

## Files

| File | What it is |
|---|---|
| `Diagnostics_and_Prototype.ipynb` | VIF, calibration, influence, robustness, risk ranking, prototype cross-check |
| `fig_d1_vif.png` | VIF bar chart |
| `fig_d2_calibration.png` | Calibration curve on the test set |
| `fig_d3_influence.png` | Cook's distance vs. leverage |
| `fig_d4_robustness.png` | Coefficients with 95% CI across three fits |
| `prototype/pre_launch_checker.html` | Live demo: open in any browser, no install needed |

The notebook reads `../Part A/...`, so run it from inside `Part D/`.

## Key findings

1. **No multicollinearity.** All VIFs are between 1.03 and 1.26. Centering worked: the interaction term's VIF is 1.03.
2. **Well calibrated.** On the test set, each decile's mean prediction is within 2.5 pts of its actual success rate. Hosmer-Lemeshow p = 0.42; Brier 0.110 vs. 0.139 for a constant 83% baseline. This supports not using class weights.
3. **No single point dominates.** Max Cook's D = 0.010. The most influential points are mostly failed campaigns that the model rated above 95%, often with goals under $100.
4. **H1, H2, H4 and H5 (reward tiers) are robust** to dropping influential points or extreme goals.
5. **⚠ H3 (goal × duration) is fragile.** p goes from 0.004 to 0.105 after dropping only 20 campaigns, and to 0.432 after dropping goals < $100 or > $1M. **For C and E:** report H3 as "supported in the main model but sensitive to extreme goals".
6. **Risk ranking.** The riskiest 20% of test campaigns fail 46% of the time (vs. 17% overall) and contain 55% of all failures (2.7× lift over random).

## Prototype: what it does

- Inputs: goal, duration, category, reward tiers, previous success, images, video
- Output: success probability, a risk tier (High risk < 70.5% = riskiest fifth of test campaigns; Moderate; Strong ≥ 89.5% = above the test median), and a comparison with the 83% average
- Risk signals: which inputs hurt or help, in odds terms, using the model's own coefficients
- What-if levers: how many points the probability moves if the creator halves the goal, shortens the campaign, or adds reward tiers
- Goal planner: the highest goal that keeps the chance of success at or above 70/80/90%
- Probabilities match statsmodels to 1e-16 (checked in Step 6 of the notebook)

**Demo script (about 60 seconds):** click *Ambitious first-timer* ($25,000, 45 days, Food, 4 tiers, no video, first-time creator): **31%, high risk**. The levers show halving the goal adds 12 pts, shortening to 30 days adds 10 pts and adding 3 reward tiers adds 7 pts. Applying the three together ($12,500, 30 days, 7 tiers) raises it to **59%**. Then click *Experienced creator*: **97%**.

## Business impact slide (draft)

**Title:** A pre-launch check that points creators to the changes that matter

- **Problem:** creators set the goal, duration and rewards before launch, and these choices can't be changed once a campaign is live. Most failures are visible in advance: the riskiest 20% of campaigns contain 55% of all failures.
- **Free tier, for every creator:** success probability, risk tier and the top risk signals. Builds trust and brings creators onto the tool.
- **Pro tier, for creators:** what-if levers and the goal planner ("the highest goal that keeps you above 80%").
- **Platform / investors:** use the score to triage which campaigns need coaching or review before launch, and to spot first-time creators with high-risk plans.
- **Why it's credible:** the probabilities are calibrated (what it says is what happens on held-out data), and every signal comes from an interpretable coefficient, not a black box.
- **Caveat to say out loud:** the data appears to include only campaigns with ≥ 10 backers, so absolute probabilities are likely optimistic; the ranking and the levers are the most reliable part.
